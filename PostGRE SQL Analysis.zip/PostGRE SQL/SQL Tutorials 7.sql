select * from payment
select * from customer

-- Create 
create or replace view customer_payment_details as 
(select c.customer_id, p.payment_id, c.first_name, c.last_name, p.amount, p.payment_date
from customer as c
join payment as p
on c.customer_id = p.customer_id)

select customer_id, amount, payment_date from customer_payment_details

--CTE (Common Table Expression)
with customer_new_details as 
(select c.customer_id, p.payment_id, c.first_name, c.last_name, p.amount, p.payment_date
from customer as c
join payment as p
on c.customer_id = p.customer_id)

select customer_id, amount, payment_date from customer_payment_details