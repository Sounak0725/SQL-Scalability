select * from film

--Case & Case Expression
select
Sum(case rating
when 'NC-17' then 1
else 0
end )as rating_class,
Sum(case rating
when 'R' then 1
else 0
end )as rating_class_mid
from film