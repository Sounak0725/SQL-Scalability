select * from payment

-- No. of payments on Moday
select count(*) from payment
where extract (dow from payment_date) = 1

-- Month Name from payment_date column
select distinct to_char(payment_date, 'MONTH') from payment

-- Subquery
select * from inventory
select * from rental
select * from film

select film_id, title from film
where film_id in
(select i.film_id from inventory as i
join rental as r
on i.inventory_id = r.inventory_id
where return_date between '28-05-2005' and '30-05-2005')
order by film_id

select * from employee_manager 
select e.employee_name, m.employee_name as manager_name,e.manager_id from employee_manager as e
join employee_manager as m
on e.manager_id = m.employee_id