SELECT * FROM customer
SELECT * FROM payment

--LIKE, AND, OR, ANY
SELECT customer_id, first_name, last_name FROM customer
WHERE first_name LIKE 'M%' AND last_name LIKE 'M%'
ORDER BY customer_id

SELECT customer_id, first_name, last_name, CONCAT(first_name,' ',last_name) AS FULL_NAME 
FROM customer
WHERE first_name LIKE 'M%' AND first_name LIKE '%a'

SELECT customer_id, first_name, last_name, CONCAT(first_name,' ',last_name) AS FULL_NAME 
FROM customer
WHERE first_name LIKE 'M%' OR first_name LIKE '%a'

SELECT customer_id, first_name, last_name, CONCAT(first_name,' ',last_name) AS FULL_NAME 
FROM customer
WHERE first_name LIKE ANY (ARRAY['M%','%a'])

SELECT customer_id, first_name, last_name, CONCAT(first_name,' ',last_name) AS FULL_NAME 
FROM customer
WHERE first_name LIKE '%ia'

SELECT customer_id, first_name, last_name, CONCAT(first_name,' ',last_name) AS FULL_NAME 
FROM customer
WHERE first_name LIKE 'M%' 

SELECT customer_id, first_name, last_name FROM customer
WHERE first_name LIKE 'M%' OR last_name LIKE '%z'

--JOINS
SELECT c.customer_id, c.first_name, c.last_name,p.payment_id, p.amount
FROM customer AS c
JOIN payment AS p
ON c.customer_id = p.customer_id
ORDER BY p.amount DESC

SELECT first_name FROM customer
WHERE first_name LIKE 'M%';

-- LEFT, RIGHT 
SELECT LEFT(first_name,2) FROM customer
WHERE first_name LIKE 'M%';

SELECT RIGHT(first_name,2) FROM customer
WHERE first_name LIKE 'M%';

SELECT CONCAT(LEFT(first_name,2),RIGHT(first_name,2)) FROM customer
WHERE first_name LIKE 'M%';

--SUBSTRING
SELECT first_name, SUBSTRING (first_name,3) AS text_elements FROM customer
WHERE first_name LIKE 'M%'

SELECT first_name, SUBSTRING (first_name,3,5) AS text_elements FROM customer
WHERE first_name LIKE 'M%'