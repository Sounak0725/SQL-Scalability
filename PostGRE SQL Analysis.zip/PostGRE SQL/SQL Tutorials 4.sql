select * from cd.bookings
select * from cd.facilities
select * from cd.members

select facid, name, membercost, monthlymaintenance from cd.facilities
where membercost > 0 and membercost < (( 1/50.0)*monthlymaintenance)

select * from cd.facilities
where facid in (1,5)

select memid,surname, firstname, joindate from cd.members
where joindate > '2012-09-01'

select distinct surname from cd.members
order by surname 
limit 10

select joindate from cd.members
order by joindate DESC
limit 1 

select count(*) from cd.facilities
where guestcost >= 10

select * from cd.bookings
select * from cd.facilities
select * from cd.members

--List of total  number of slots booked per facility
select facid, sum(slots) as total_slots from cd.bookings 
group by facid
having sum(slots)> 1000
order by facid

select b.starttime, f.name from cd.bookings as b
join cd.facilities as f
on b.facid = f.facid
where f.facid in (0,1) and 
b.starttime >= '2012-09-21' and 
b.starttime <= '2012-09-22'
order by b.starttime

select b.starttime, concat(m.firstname || ' ' || m.surname) as fullname from cd.bookings as b
join cd.members as m
on b.memid = m.memid
where m.firstname = 'David' and m.surname = 'Farrell'
order by b.starttime







