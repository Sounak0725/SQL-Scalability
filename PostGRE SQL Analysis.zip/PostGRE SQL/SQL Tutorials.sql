CREATE TABLE customers
("CustID" int8 PRIMARY KEY, 
"CustName" varchar(50) NOT NULL, 
"Age" int NOT NULL, 
"City" char(50),
"Salary" numeric);

SELECT * FROM customers
ORDER BY "CustID";

INSERT INTO customers
("CustID", "CustName", "Age", "City", "Salary")
VALUES
(1,'Sam',26,'Delhi', 9000),
(2,'Ram',30,'Kolkata', 10000),
(3,'Jadu',24,'Mumbai', 15000),
(4,'Madhu',25,'Delhi', 6000);

UPDATE customers
SET "CustName" = 'Xam', "Age" = 40, "City" = 'Chennai', "Salary" = 50000
WHERE "CustID" = 3;

DELETE FROM customers
Where "CustID" = 4;

SELECT * FROM customers
