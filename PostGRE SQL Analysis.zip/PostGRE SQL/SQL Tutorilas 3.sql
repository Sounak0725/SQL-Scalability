-- Comment
-- Create Table and Insert Values
CREATE TABLE employee_manager
("employee_id" int8 PRIMARY KEY, 
"employee_name" varchar(50),
"manager_id" int8
);

INSERT INTO employee_manager
(employee_id, employee_name, manager_id)
VALUES
(1, 'Ram', 2),
(2, 'Sham', 4),
(3, 'Jadu', 4),
(4, 'Madhu', 1);

TRUNCATE TABLE employee_manager
Select * from employee_manager

ALTER TABLE employee_manager
ADD COLUMN manager_id int8;
manager_name VARCHAR(50);

ALTER TABLE employee_manager
DROP COLUMN manager_name;

ALTER TABLE employee_manager
RENAME TO manager_employee;

Select * from manager_employee
DROP TABLE manager_employee
ALTER TABLE employee_manager
DROP COLUMN manager_id

ALTER TABLE manager_employee
CHANGE employee_id id int8 PRIMARY KEY;

--JOINS
select * from employee_manager AS E1
join employee_manager AS M1
ON E1.manager_id = M1.employee_id

-- SELF JOIN
select E1.employee_id, E1.employee_name AS Emp_Name, M1.employee_name AS Mng_Name
from employee_manager AS E1
join employee_manager AS M1
ON E1.manager_id = M1.employee_id

-- TIMESTAMP
SHOW TIMEZONE
SELECT NOW()
SELECT EXTRACT(YEAR FROM NOW())

-- BETWEEN
SELECT payment_id FROM payment
WHERE payment_id BETWEEN 17500 AND 17650
ORDER BY payment_id DESC

-- SUB QUERY
SELECT * FROM payment
WHERE amount > (SELECT AVG(amount) AS avg_amount FROM payment)
ORDER BY customer_id

--CASE
SELECT customer_id, amount,
CASE 
    WHEN amount> 6 THEN 'Best'
    WHEN amount> 3 THEN 'Ordinary'
    ELSE 'Worse'
END AS Amount_Quality
FROM payment

--Case Expression
SELECT customer_id,
CASE  amount
    WHEN 6 THEN 'Best'
    WHEN 3 THEN 'Ordinary'
    ELSE 'Worse'
END AS Amount_Quality
FROM payment

SELECT count(first_name) from customer;

-- GROUP BY, HAVING
SELECT * FROM payment

SELECT customer_id, SUM(amount) AS total_amount FROM payment
WHERE customer_id IN (148, 178,526,144,459)
GROUP BY customer_id
HAVING SUM(amount) > 100
ORDER BY total_amount DESC;